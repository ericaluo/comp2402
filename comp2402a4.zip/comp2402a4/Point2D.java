package comp2402a4;

public class Point2D {
	public int x, y;
	
	public String toString() {
		return "(" + x + "," + y + ")";
	}
}
